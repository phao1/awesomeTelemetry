import js from '@eslint/js';
import tseslint from 'typescript-eslint';

export default tseslint.config(
  { ignores: ['dist', 'server-dist', 'dist-binary', 'src/generated', 'node_modules'] },
  js.configs.recommended,
  ...tseslint.configs.recommended,
  {
    rules: {
      '@typescript-eslint/consistent-type-imports': 'error',
      '@typescript-eslint/no-explicit-any': 'warn',
      // AGENTS.md 禁令 4：同步子进程 / 同步大文件读不得进请求路径
      'no-restricted-syntax': ['error',
        { selector: "CallExpression[callee.name='spawnSync']", message: 'AGENTS.md 禁令 4：禁止 spawnSync，用 spawn + Promise' },
        { selector: "CallExpression[callee.name='execFileSync']", message: 'AGENTS.md 禁令 4：禁止 execFileSync，用 execFile + Promise' },
      ],
    },
  },
);
